const Bdata = [
  {
    id: 1,
    imgsrc: "/images/blog-img-1.jpg",
    pname: "Cheezy Pizza Toppins",
    price:
      "Mauris fermentum dictum magna. Sed laoreet ali­quam leo. Ut tellus dolor, dapibus eget, elementum vel, cursus eleifend, elit.",
  },
  {
    id: 2,
    imgsrc: "/images/blog-img-2.jpg",
    pname: "Cheezy Pizza Toppins",
    price:
      "Mauris fermentum dictum magna. Sed laoreet ali­quam leo. Ut tellus dolor, dapibus eget, elementum vel, cursus eleifend, elit.",
  },
  {
    id: 3,
    imgsrc: "/images/blog-img-3.jpg",
    pname: "Cheezy Pizza Toppins",
    price:
      "Mauris fermentum dictum magna. Sed laoreet ali­quam leo. Ut tellus dolor, dapibus eget, elementum vel, cursus eleifend, elit.",
  },
  {
    id: 4,
    imgsrc: "/images/blog-img-4.jpg",
    pname: "Cheezy Pizza Toppins",
    price:
      "Mauris fermentum dictum magna. Sed laoreet ali­quam leo. Ut tellus dolor, dapibus eget, elementum vel, cursus eleifend, elit.",
  },
  {
    id: 5,
    imgsrc: "/images/blog-img-5.jpg",
    pname: "Cheezy Pizza Toppins",
    price:
      "Mauris fermentum dictum magna. Sed laoreet ali­quam leo. Ut tellus dolor, dapibus eget, elementum vel, cursus eleifend, elit.",
  },
  {
    id: 6,
    imgsrc: "/images/blog-img-6.jpg",
    pname: "Cheezy Pizza Toppins",
    price:
      "Mauris fermentum dictum magna. Sed laoreet ali­quam leo. Ut tellus dolor, dapibus eget, elementum vel, cursus eleifend, elit.",
  },
  {
    id: 7,
    imgsrc: "/images/blog-img-7.jpg",
    pname: "Cheezy Pizza Toppins",
    price:
      "Mauris fermentum dictum magna. Sed laoreet ali­quam leo. Ut tellus dolor, dapibus eget, elementum vel, cursus eleifend, elit.",
  },
  {
    id: 8,
    imgsrc: "/images/blog-img-8.jpg",
    pname: "Cheezy Pizza Toppins",
    price:
      "Mauris fermentum dictum magna. Sed laoreet ali­quam leo. Ut tellus dolor, dapibus eget, elementum vel, cursus eleifend, elit.",
  },
  {
    id: 9,
    imgsrc: "/images/blog-img-9.jpg",
    pname: "Cheezy Pizza Toppins",
    price:
      "Mauris fermentum dictum magna. Sed laoreet ali­quam leo. Ut tellus dolor, dapibus eget, elementum vel, cursus eleifend, elit.",
  },
  {
    id: 10,
    imgsrc: "/images/blog-img-10.jpg",
    pname: "Cheezy Pizza Toppins",
    price:
      "Mauris fermentum dictum magna. Sed laoreet ali­quam leo. Ut tellus dolor, dapibus eget, elementum vel, cursus eleifend, elit.",
  },
  {
    id: 11,
    imgsrc: "/images/blog-img-11.jpg",
    pname: "Cheezy Pizza Toppins",
    price:
      "Mauris fermentum dictum magna. Sed laoreet ali­quam leo. Ut tellus dolor, dapibus eget, elementum vel, cursus eleifend, elit.",
  },
  {
    id: 12,
    imgsrc: "/images/blog-img-12.jpg",
    pname: "Cheezy Pizza Toppins",
    price:
      "Mauris fermentum dictum magna. Sed laoreet ali­quam leo. Ut tellus dolor, dapibus eget, elementum vel, cursus eleifend, elit.",
  },
];

export default Bdata;
