import React, { createContext } from "react";

const Context = createContext();

export default Context;
